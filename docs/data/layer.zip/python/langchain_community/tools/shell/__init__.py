"""Shell tool."""

from langchain_community.tools.shell.tool import ShellTool

__all__ = ["ShellTool"]
