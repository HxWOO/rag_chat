from langchain_community.retrievers.pubmed import PubMedRetriever

__all__ = [
    "PubMedRetriever",
]
